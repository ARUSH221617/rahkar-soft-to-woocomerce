<?php
// if uninstall.php is not called by WordPress, die
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    die;
}

$option_name = 'rka_options';

delete_option( $option_name );

// for site options in Multisite
//delete_site_option( $option_name );

add_action( 'admin_menu', 'rahkar_arush_remove_options_page', 99 );
function rahkar_arush_remove_options_page() {
    remove_menu_page( 'rahkar_arush' );
}

// drop a custom database table
global $wpdb;
$wpdb->query( "DROP TABLE IF EXISTS `{$wpdb->prefix}rahkar-arush`" );
