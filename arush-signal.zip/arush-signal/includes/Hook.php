<?php
register_uninstall_hook(
    __FILE__,
    'pluginprefix_function_to_run'
);
function register_custom_hook_arush(): void
{
    /**
     * Register the "book" custom post type
     */
    function pluginprefix_setup_post_type(): void
    {
        register_post_type( 'book', ['public' => true ] );
    }
    add_action( 'init', 'pluginprefix_setup_post_type' );


    /**
     * Activate the plugin.
     */
    function pluginprefix_activate(): void
    {
    // Trigger our function that registers the custom post type plugin.
        pluginprefix_setup_post_type();
    // Clear the permalinks after the post type has been registered.
        flush_rewrite_rules();
    }
    register_activation_hook( __FILE__, 'pluginprefix_activate' );
    return;
}
function unregister_custom_hook_arush(): void
{
    /**
     * Deactivation hook.
     */
    function pluginprefix_deactivate(): void
    {
        // Unregister the post type, so the rules are no longer in memory.
        unregister_post_type( 'book' );
        // Clear the permalinks to remove our post type's rules from the database.
        flush_rewrite_rules();
    }
    register_deactivation_hook( __FILE__, 'pluginprefix_deactivate' );
}