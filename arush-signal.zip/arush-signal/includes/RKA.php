<?php

namespace RKA\Core;

class RKA extends Database
{
    public function __construct()
    {
        parent::__construct();
    }

    public function update(): bool|array
    {

        $this->updateCategorys();
        $this->updateProducts();
        return true;
    }

    public function updateCategorys()
    {
        $categorys = $this->filterCategorys();
        $rpa = [];
        if (count($categorys) > 0) foreach ($categorys as $category) {

//Create post
            $category_id = wp_create_category($category->name);
            $rpa[] = $category_id;
            $this->add_category_to_wpdb_rka($category_id, $category->id);
        }
        return $rpa;
    }

    public function filterCategorys(): array
    {
        $categorys = [];

        $mscategorys = $this->getCategorys();

        foreach ($mscategorys as $category) {
            if (!$this->wpdb_rka_exist_category_by_category_id($category->id)) {
                $categorys[] = $category;
            }
        }
        return $categorys;
    }

    public function updateProducts()
    {
        $products = $this->filterProducts();
        $rpa = [];
        if (count($products) > 0) foreach ($products as $product) {
            $post = [
                'post_author' => "1",
                'post_content' => $product->content,
                'post_status' => "publish",
                'post_title' => $product->name,
                'post_parent' => '',
                'post_type' => "product",
                'post_date' => date('Y-m-d H:i:s', time()),
                'post_category' => $product->category,
                'tags_input' => $product->tags
            ];

//Create post
            $post_id = wp_insert_post($post, true);
            $rpa[] = $post_id;
            $this->add_product_to_wpdb_rka($post_id, $product->code);
            if ($post_id) {
                $attach_id = get_post_meta($product->id, "_thumbnail_id", true);
                add_post_meta($post_id, '_thumbnail_id', $attach_id);
            }

            update_post_meta($post_id, '_visibility', 'visible');
            update_post_meta($post_id, '_stock_status', 'instock');
            update_post_meta($post_id, 'total_sales', '0');
            update_post_meta($post_id, '_downloadable', 'no');
            update_post_meta($post_id, '_virtual', 'no');
            update_post_meta($post_id, '_regular_price', $product->price);
            update_post_meta($post_id, '_sale_price', $product->offerprice);
            update_post_meta($post_id, '_featured', "no");
            update_post_meta($post_id, '_sku', $product->code);
            update_post_meta($post_id, '_product_attributes', []);
            update_post_meta($post_id, '_sale_price_dates_from', "");
            update_post_meta($post_id, '_sale_price_dates_to', "");
            update_post_meta($post_id, '_price', $product->price);
            update_post_meta($post_id, '_manage_stock', "no");
            update_post_meta($post_id, '_backorders', "no");
            update_post_meta($post_id, '_stock', "");
        }
        return $rpa;
    }

    public function filterProducts(): array
    {
        $products = [];

        $msproducts = $this->getProducts();

        foreach ($msproducts as $product) {
            if (!$this->wpdb_rka_exist_product_by_product_id($product->code)) {
                $products[] = $product;
            }
        }
        return $products;
    }
}