<?php
namespace RKA;

use RKA\Core\RKA;

class Admin
{
    public function __construct()
    {
        /**
         * Register our rka_settings_init to the admin_init action hook.
         */
        add_action('admin_init', [$this, 'rka_settings_init']);

        /**
         * Register our rka_config_setting_init to the admin_init action hook.
         */
        add_action('admin_init', [$this, 'rka_config_setting_init']);

        /**
         * Register our rka_options_page to the admin_menu action hook.
         */
        add_action('admin_menu', [$this, 'rka_options_page']);

        /**
         * Register our rka_submenu_config_page to the admin_menu action hook.
         */
        add_action('admin_menu', [$this, 'rka_submenu_config_page']);
    }

    /**
     * @internal never define functions inside callbacks.
     * these functions could be run multiple times; this would result in a fatal error.
     */

    /**
     * custom option and settings
     */
    public function rka_settings_init()
    {
        // Register a new setting for "rka" page.
        register_setting('rka', 'rka_options');

        // Register a new section in the "rka" page.
        add_settings_section(
            'rka_section_developers',
            __('بروزسانی محصولات', 'rka'),
            [$this, 'rka_section_developers_callback'],
            'rka'
        );
    }

    public function rka_config_setting_init()
    {
        // Register a new setting for "rka_config" page.
        register_setting('rka_config', 'rka_config_options');

        // Register a new section in the "rka_config" page.
        add_settings_section(
            'rka_config_section_developers',
            __('تنظیمات افزونه', 'rka_config'),
            [$this, 'rka_config_section_developers_callback'],
            'rka_config'
        );

        add_settings_field(
            'dbhost',
            'آدرس هاست یا سرور',
            [$this, 'rka_config_field_callback'],
            'rka_config',
            'rka_config_section_developers',
            [
                'label_for' => 'rka_dbhost'
            ]
        );

        add_settings_field(
            'dbname',
            'نام دیتابیس',
            [$this, 'rka_config_field_callback'],
            'rka_config',
            'rka_config_section_developers',
            [
                'label_for' => 'rka_dbname'
            ]
        );

        add_settings_field(
            'dbuser',
            'نام کاربری',
            [$this, 'rka_config_field_callback'],
            'rka_config',
            'rka_config_section_developers',
            [
                'label_for' => 'rka_dbuser'
            ]
        );

        add_settings_field(
            'dbpass',
            'رمزعبور',
            [$this, 'rka_config_field_callback'],
            'rka_config',
            'rka_config_section_developers',
            [
                'label_for' => 'rka_dbpass'
            ]
        );
    }

    public function rka_config_field_callback($args)
    {
        $type = !empty($args['type']) ? ' type="' . $args['type'] . '"' : 'type="text"';
        $id = !empty($args['label_for']) ? ' id="' . $args['label_for'] . '"' : '';
        $name = !empty($args['label_for']) ? ' name="' . $args['label_for'] . '"' : '';
        $class = !empty($args['class']) ? ' class="' . implode(' ', $args['class']) . '"' : 'class="rka-input form-control"';
        $value = !empty($args['value']) ? ' value="' . $args['value'] . '"' : '';
        $placeholder = !empty($args['placeholder']) ? ' placeholder="' . $args['placeholder'] . '"' : '';
        $label_for = !empty($args['label_for']) ? ' for="' . $args['label_for'] . '"' : '';
        $inputDBHOST = sprintf('<input %s %s %s %s %s %s>', $type, $id, $name, $class, $value, $placeholder);
        echo $inputDBHOST;
    }

    /**
     * Custom option and settings:
     *  - callback functions
     */


    /**
     * Developers section callback function.
     *
     * @param array $args  The settings array, defining title, id, callback.
     */
    public function rka_section_developers_callback($args)
    {
        ?>
        <p id="<?php echo esc_attr($args['id']); ?>"><?php esc_html_e('با زدن دکمه بروزرسانی محصولاتی که در نرم افزار راهکارسافت وارد کردید به وردپرس اضافه می شود.', 'rka'); ?></p>
        <?php
    }

    /**
     * Custom option and settings:
     *  - callback functions
     */


    /**
     * Developers section callback function.
     *
     * @param array $args  The settings array, defining title, id, callback.
     */
    public function rka_config_section_developers_callback($args)
    {
        ?>
        <p id="<?php echo esc_attr($args['id']); ?>"><?php esc_html_e('این اطلاعات را سرویس اراعه دهنده شما باید در اختیار شما بگذارد.', 'rka_config'); ?></p>
        <?php
    }

    /**
     * Add the top level menu page.
     */
    public function rka_options_page()
    {
        $hookname = add_menu_page(
            'RahkarPOS to WooCommerce',
            'ARUSH',
            'manage_options',
            'rka',
            [$this, 'rka_options_page_html'],
            RAHKAR_ARUSH_URL . 'logo-icon.svg',
            30
        );
        add_action('load-' . $hookname, [$this, 'rka_options_page_submit']);
    }

    public function rka_options_page_submit(): void
    {
        if ('POST' === $_SERVER['REQUEST_METHOD']) {
            $rka = new RKA();
            $_rka_ = $rka->update();
            add_settings_error('rka_messages', 'rka_message', __(sprintf("%s محصول اضافه شد.", count($_rka_)), 'rka'), 'success');
        }
    }

    /**
     * Top level menu callback function
     */
    public function rka_options_page_html()
    {
        // check user capabilities
        if (!current_user_can('manage_options')) {
            return;
        }

        // add error/update messages

        // check if the user have submitted the settings
        // WordPress will add the "settings-updated" $_GET parameter to the url
        if (isset($_GET['settings-updated'])) {
            // add settings saved message with the class of "updated"
            add_settings_error('rka_messages', 'rka_message', __('بروزرسانی انجام شد', 'rka'), 'updated');
        }

        // show error/update messages
        settings_errors('rka_messages');
        ?>
        <div class="wrap">
            <h1>
                <?php echo esc_html(get_admin_page_title()); ?>
            </h1>
            <form action="<?php menu_page_url('rka') ?>" method="post">
                <?php
                // output security fields for the registered setting "rka"
                settings_fields('rka');
                // output setting sections and their fields
                // (sections are registered for "rka", each field is registered to a specific section)
                do_settings_sections('rka');
                // output save settings button
                submit_button('بروزرسانی');
                ?>
            </form>
        </div>
        <?php
    }

    public function rka_submenu_config_page()
    {
        $hookname = add_submenu_page(
            'rka',
            'RahkarPOS to Woo > Config',
            'Config',
            'manage_options',
            'rka_config',
            [$this, 'rka_submenu_config_page_html']
        );

        add_action('load-' . $hookname, [$this, 'rka_submenu_config_page_html_submit']);
    }

    public function rka_submenu_config_page_html_submit(): void
    {
        if ('POST' === $_SERVER['REQUEST_METHOD']) {
            $rka = new RKA();
            $_rka_ = $rka->update();
            add_settings_error('rka_messages', 'rka_message', __(sprintf("%s محصول اضافه شد.", count($_rka_)), 'rka'), 'success');
        }
    }

    public function rka_submenu_config_page_html()
    {
        // check user capabilities
        if (!current_user_can('manage_options')) {
            return;
        }

        // add error/update messages

        // check if the user have submitted the settings
        // WordPress will add the "settings-updated" $_GET parameter to the url
        if (isset($_GET['settings-updated'])) {
            // add settings saved message with the class of "updated"
            add_settings_error('rka_config_messages', 'rka_config_messages', __('بروزرسانی انجام شد', 'rka'), 'updated');
        }

        // show error/update messages
        settings_errors('rka_config_messages');
        ?>
        <div class="wrap">
            <h1>
                <?php echo esc_html(get_admin_page_title()); ?>
            </h1>
            <div id="rka_logo">
                <h1><a href="<?= ARUSH_SITE_ADDRESS ?>">ARUSH</a></h1>
                <div></div>
            </div>
            <form action="<?php menu_page_url('rka_config') ?>" method="post" class="rka-form">
                <?php
                // output security fields for the registered setting "wporg_options"
                settings_fields('rka_config_options');
                // output setting sections and their fields
                // (sections are registered for "wporg", each field is registered to a specific section)
                do_settings_sections('rka_config');
                // output save settings button
                submit_button(__('Save Settings', 'textdomain'));
                ?>
            </form>
        </div>
        <style>
            .rka-form {
                width: 550px;
                height: auto;
                border: .5px solid #B71C1C;
                border-radius: 15px;
                margin: auto;
                padding: 15px;
                background-color: #fff;
            }

            .rka-form table tbody tr {
                display: flex;
                flex-direction: column;
                align-content: center;
                align-items: stretch;
                justify-content: center;
            }

            .rka-form [type=submit] {
                width: 100%;
                min-height: 52px;
                color: #f9f9f9;
                background-color: #B71C1C;
                border: none;
                border-radius: 15px;
                transition: all .5s ease;
                font-size: 16px;
                font-size: 16px;
            }

            .rka-form h2 {
                font-size: 26px;
            }

            .rka-form p {
                font-size: 16px;
            }

            .rka-form [type=submit]:hover {
                color: #f9f9f9;
                background-color: #B71C1C;
                border: .5px solid #B71C1C;
                scale: 1.1;
            }

            input.rka-input {
                background-color: #fff;
                color: #000;
                border: .1px solid #eee;
                border-radius: 15px;
                font-size: 16px;
                text-align: start;
                display: block;
                position: relative;
                width: 100%;
                min-height: 52px;
            }

            input.rka-input:focus {
                border: .5px solid #B71C1C;
            }

            #rka_logo {
                width: 550px;
                height: auto;
                display: flex;
                justify-content: center;
                align-items: center;
                margin: auto;
                padding: 15px 8px;
                /* align-content: center; */
                flex-direction: row-reverse;
            }

            #rka_logo h1 {
                font-size: 30px;
                font-family: system-ui, Tahoma;
            }

            #rka_logo h1 a {
                color: #000;
                font-weight: bold;
                text-decoration: none;
            }

            #rka_logo div {
                border-radius: 100%;
                width: 75px;
                height: 75px;
                margin-left: 20px;
                border: 5px solid #B71C1C;
                background: url("<?= RAHKAR_ARUSH_URL ?>icon.png");
                background-position: center;
                background-repeat: no-repeat;
                background-size: 100vh;
                background-color: #fff;
            }
        </style>
        <?php
    }
}