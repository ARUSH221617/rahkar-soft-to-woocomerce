<?php

namespace RKA\Core;

use RKA\Admin;
use RKA\Config;
use wpdb;

class Database extends Config
{
    public function __construct()
    {
        parent::__construct();
        $this->wpdb_init();
        $this->getDB();
    }

    public function wpdb_init(): bool
    {
        if ($this->getWPDB()->get_var($this->getWPDB()->prepare("SELECT count(*) FROM information_schema.tables WHERE table_schema = '%s' AND table_name = '%s';", ['wp_signal', $this->wp_p_tblname])) != $this->wp_p_tblname) {
            register_activation_hook(RAHKAR_ARUSH_PATH . "arush-signal.php", [$this, "wpdb_create_tb_rka"]);
            $this->wp_rka_table = true;
            return true;
        }
        $this->wp_rka_table = true;
        return true;
    }

    public function getWPDB(): wpdb
    {
        global $wpdb;
        return $wpdb;
    }

    public function wpdb_create_tb_rka(): void
    {
        $query = sprintf(
            "CREATE TABLE `%s` (
            id int(11) NOT NULL AUTO_INCREMENT,
            wc_product_id int(11) NOT NULL,
            product_id int(11) NOT NULL,
            PRIMARY KEY (id)
            ) %s;",
            $this->getWPPTableName(),
            $GLOBALS["charset_collate"]
        );
        require_once(ABSPATH . '/wp-admin/includes/upgrade.php');
        dbDelta($query);
    }

    public function wpdb_rka_exist_product_by_product_id($product_id): bool|int
    {
        $check = $this->getWPDB()->get_var($this->getWPDB()->prepare("SELECT COUNT(*) FROM `{$this->getWPPTableName()}` WHERE `product_id`=%d;", [$product_id]));
        return ($check != 0);
    }

    public function add_product_to_wpdb_rka(int $id, int $product_id)
    {
        return $this->getWPDB()->insert($this->getWPPTableName(), ['wc_product_id' => $id, 'product_id' => $product_id]);
    }
    
    public function wpdb_rka_exist_category_by_category_id($category_id): bool|int
    {
        $check = $this->getWPDB()->get_var($this->getWPDB()->prepare("SELECT COUNT(*) FROM `{$this->getWPCTableName()}` WHERE `category_id`=%d;", [$category_id]));
        return ($check != 0);
    }

    public function add_category_to_wpdb_rka(int $id, int $category_id)
    {
        return $this->getWPDB()->insert($this->getWPCTableName(), ['wc_category_id' => $id, 'category_id' => $category_id]);
    }

    public function db_config()
    {
        $defualt = [
            'rka_dbhost' => $this->getDBHost(),
            'rka_dbname' => $this->getDBName(),
            'rka_dbuser' => $this->getDBUser(),
            'rka_dbpass' => $this->getDBPass(),
        ];
        return [
            'host' => !empty(get_option('rka_dbhost')) ? get_option('rka_dbhost') : $defualt['rka_dbhost'],
            'name' => !empty(get_option('rka_dbname')) ? get_option('rka_dbname') : $defualt['rka_dbname'],
            'user' => !empty(get_option('rka_dbuser')) ? get_option('rka_dbuser') : $defualt['rka_dbuser'],
            'pass' => !empty(get_option('rka_dbpass')) ? get_option('rka_dbpass') : $defualt['rka_dbpass']
        ];
    }

    public function getDB()
    {
        $database_config = $this->db_config();
        if (function_exists("sqlsrv_configure")) {
            sqlsrv_configure('WarningsReturnAsErrors', 0);
        }
        $connectionInfo = array("Database" => $database_config["name"], "Uid" => $database_config["user"], "PWD" => $database_config["pass"], "CharacterSet" => "UTF-8");

        /* Connect using SQL Server Authentication. */
        if (function_exists("sqlsrv_connect")) {
            $conn = sqlsrv_connect($database_config["host"], $connectionInfo);
        }

        if (!$conn) {
            if (function_exists("sqlsrv_errors")) {
                // error_log("Error in statement execution.\n".implode(' \n ', sqlsrv_errors()));
            }
        }

        $this->mssql = ($conn) ? $conn : null;
        return ($conn) ? $conn : false;
    }

    public function msquery($query)
    {
        if (function_exists("sqlsrv_query") && $this->mssql) {
            $msquery = sqlsrv_query($this->mssql, $query);
        } else {
            $msquery = false;
            $this->error_log("has one error in function msquery in class Database: function sqlsrv_query don`t exist! or mssql don't set!");
        }
        return $msquery;
    }

    public function msfetch($msquery)
    {
        if (function_exists("sqlsrv_fetch_object") && $msquery) {
            $msfo = sqlsrv_fetch_object($msquery);
        } else {
            $msfo = false;
            $this->error_log("has one error in function msfetch in class Database: function sqlsrv_query don`t exist! or msquery don't set!");
        }
        return $msfo;
    }

    public function getProducts()
    {
        $query = "SELECT [RowID], [GoodCategory_ID], [Main_MeasureUnit_ID], [Default_MeasureUnit_ID], [Fix_GoodType_ID], [DiscountGroupGood_ID], [TaxGroupGood_ID], [RowCode], [RowName], [RowNameEN], [RowNameAlias], [PurchasePrice], [SalePrice], [IMG_1], [OrderPoint], [FirstStock], [DiscountPrice], [IsActive], [RowDesc], [InsertedBy], [UpdatedBy], [FDateInsert], [FDateUpdate], [FTimeInsert], [FTimeUpdate], [InsertServerDateTime], [UpdateServerDateTime], [IsSend] FROM [RahkarPOSDB].[dbo].[Good]";

        $msquery = sqlsrv_query($this->mssql, $query);

        if (!$msquery) {
            echo "Error in statement execution.\n";
            die(print_r(sqlsrv_errors(), true));
        }

        $products = [];

        while ($product = sqlsrv_fetch_object($msquery)) {
            $id = $product->RowID;
            $name = $product->RowName;
            $description = $product->RowDesc;
            $isActivate = $product->IsActive;
            $price = $product->SalePrice;
            $offerprice = $product->DiscountPrice;
            $code = $product->RowCode;
            $image = ""; // $product->image;
            $category = []; // $this->getCategories($product->GoodCategory_ID);
            $tags = []; //$product->tags;
            $products[] = new class ($id, $name, $description, $isActivate, $price, $offerprice, $code, $image, $category, $tags) {
                public $id;
                public $name;
                public $content;
                public $isActivate;
                public $price;
                public $offerprice;
                public $code;
                public $image;
                public $category;
                public $tags;
                public function __construct($id, $name, $description, $isActivate, $price, $offerprice, $code, $image, $category, $tags)
                {
                    $this->id = $id;
                    $this->name = $name;
                    $this->content = $description;
                    $this->isActivate = $isActivate;
                    $this->price = $price;
                    $this->offerprice = $offerprice;
                    $this->code = $code;
                    $this->image = $image;
                    $this->category = $category;
                    $this->tags = $tags;
                }
            };
        }
        sqlsrv_free_stmt($msquery);
        return $products;
    }

    public function getCategorys()
    {
        $query = "SELECT [RowID], [Branch_ID], [GoodCategory_ID], [RowCode], [RowName], [IsActive], [RowDesc], [UpdatedBy], [FDateInsert], [FDateUpdate], [FTimeInsert], [FTimeUpdate], [InsertServerDateTime], [UpdateServerDateTime], [RowUpdateVersion], [UniqueIdentifierValue], [ConvertRowID], [IsSend] FROM [RahkarPOSDB].[dbo].[GoodCategory]";

        $msquery = $this->msquery($query);

        $categorys = [];

        while ($category = $this->msfetch($msquery)) {
            $id = $category->RowID;
            $name = $category->RowName;
            $description = $category->RowDesc;
            $isActivate = $category->IsActive;
            $categorys[] = new class ($id, $name, $description, $isActivate) {
                public $id;
                public $name;
                public $content;
                public $isActivate;
                public function __construct($id, $name, $description, $isActivate)
                {
                    $this->id = $id;
                    $this->name = $name;
                    $this->content = $description;
                    $this->isActivate = $isActivate;
                }
            };
        }
        sqlsrv_free_stmt($msquery);
        return $categorys;
    }

    public function getCategory_by_id($id)
    {
        $query = "SELECT [RowID], [GoodCategory_ID], [Main_MeasureUnit_ID], [Default_MeasureUnit_ID], [Fix_GoodType_ID], [DiscountGroupGood_ID], [TaxGroupGood_ID], [RowCode], [RowName], [RowNameEN], [RowNameAlias], [PurchasePrice], [SalePrice], [IMG_1], [OrderPoint], [FirstStock], [DiscountPrice], [IsActive], [RowDesc], [InsertedBy], [UpdatedBy], [FDateInsert], [FDateUpdate], [FTimeInsert], [FTimeUpdate], [InsertServerDateTime], [UpdateServerDateTime], [IsSend] FROM [RahkarPOSDB].[dbo].[Good]";

        $msquery = sqlsrv_query($this->mssql, $query);

        if (!$msquery) {
            $this->error_log(sqlsrv_errors());
        }

        $products = [];

        while ($product = sqlsrv_fetch_object($msquery)) {
            $id = $product->RowID;
            $name = $product->RowName;
            $description = $product->RowDesc;
            $isActivate = $product->IsActive;
            $price = $product->SalePrice;
            $offerprice = $product->DiscountPrice;
            $code = $product->RowCode;
            $image = $product->image;
            $category = $product->GoodCategory_ID;
            $tags = []; //$product->tags;
            $products[] = new class ($id, $name, $description, $isActivate, $price) {
                public $id;
                public $name;
                public $content;
                public $isActivate;
                public $price;
                public function __construct($id, $name, $description, $isActivate, $price)
                {
                    $this->id = $id;
                    $this->name = $name;
                    $this->content = $description;
                    $this->isActivate = $isActivate;
                    $this->price = $price;
                }
            };
        }
        sqlsrv_free_stmt($msquery);
        return $products;
    }

    /**
     * @return string
     */
    public function getWPPTableName(): string
    {
        return $this->wp_p_tblname;
    }
    
    /**
     * @return string
     */
    public function getWPCTableName(): string
    {
        return $this->wp_c_tblname;
    }

    /**
     * @param string $dbHost
     * @return Database
     */
    public function setDBHost(string $dbHost): Database
    {
        $this->dbHost = $dbHost;
        return $this;
    }

    /**
     * @return string
     */
    public function getDBHost(): string
    {
        return $this->dbHost;
    }

    /**
     * @return int
     */
    public function getDBPort(): int
    {
        return $this->dbPort;
    }

    /**
     * @param int $dbPort
     * @return Database
     */
    public function setDBPort(int $dbPort): Database
    {
        $this->dbPort = $dbPort;
        return $this;
    }

    /**
     * @param string $dbUser
     * @return Database
     */
    public function setDBUser(string $dbUser): Database
    {
        $this->dbUser = $dbUser;
        return $this;
    }

    /**
     * @return string
     */
    public function getDBUser(): string
    {
        return $this->dbUser;
    }

    /**
     * @param string $dbPass
     * @return Database
     */
    public function setDBPass(string $dbPass): Database
    {
        $this->dbPass = $dbPass;
        return $this;
    }

    /**
     * @param bool $err
     * @return Database
     */
    public function setErr(bool $err): Database
    {
        $this->err = $err;
        return $this;
    }

    /**
     * @return bool
     */
    public function isErr(): bool
    {
        return $this->err;
    }

    /**
     * @param string $dbName
     * @return Database
     */
    public function setDBName(string $dbName): Database
    {
        $this->dbName = $dbName;
        return $this;
    }

    /**
     * @return Database|string
     */
    public function getDBName(): self|string
    {
        return $this->dbName;
    }

    /**
     * @return Database|string
     */
    public function getDBPass(): self|string
    {
        return $this->dbPass;
    }

    public function disconnect(): void
    {
        sqlsrv_close($this->mssql);
        $this->mssql = null;
    }

}