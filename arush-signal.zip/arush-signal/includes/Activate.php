<?php

namespace RKA;

use RKA\Core\Database;
use RKA\Core\RKA;
use RKA\Admin;

class Activate
{
    public function __construct()
    {
        $cf = new \RKA\Config();
        $cf->__construct();
        
        $db = new Database();
        $db->__construct();
        
        $rka = new RKA();
        $rka->__construct();

        $adm = new Admin();
        $adm->__construct();
    }
}