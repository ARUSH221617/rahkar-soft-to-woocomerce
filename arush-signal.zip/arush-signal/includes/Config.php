<?php

namespace RKA;

use mysqli_result;

class Config
{
    public string $dbHost;
    public int $dbPort;
    public string $dbUser;
    public string $dbPass;
    public string $dbName;
    public bool $err;
    public $mssql;
    public string $wp_p_tblname;
    public string $wp_c_tblname;
    /**
     * @var array|bool|int|mysqli_result|resource|null
     */
    public $wp_rka_table;

    public function __construct()
    {
        $dbHost = 'DESKTOP-GE6OBGM\SQLEXPRESS';
        $dbUser = '';
        $dbPass = '';
        $dbPort = 1433;
        $dbName = 'RahkarPOSDB';
        $error_showing = false;

        $this->wp_p_tblname = $GLOBALS["wpdb"]->prefix . 'product_rahkar_arush';
        $this->wp_c_tblname = $GLOBALS["wpdb"]->prefix . 'category_rahkar_arush';

        $this->cf_init(db: [
            'host' => $dbHost,
            'user' => $dbUser,
            'pass' => $dbPass,
            'port' => $dbPort,
            'name' => $dbName,
            'err'  => $error_showing
        ]);
    }

    public function cf_init($db = []): void
    {
        $this->dbHost = empty($db['host']) ? 'DESKTOP-GE6OBGM\SQLEXPRESS' : $db['host'];
        $this->dbPort = empty($db['port']) ? 1433 : $db['port'];
        $this->dbUser = empty($db['user']) ? '' : $db['user'];
        $this->dbPass = empty($db['pass']) ? '' : $db['pass'];
        $this->dbName = empty($db['name']) ? 'RahkarPOSDB' : $db['name'];
        $this->err = empty($db['err']) ? false : $db['err'];

        $this->setVersion();
    }

    private function setVersion(): string
    {
        if (!get_option("rka_version")) {
            add_option('rka_version', '1.0');
            return "1.0";
        } else {
            return $this->getVersion();
        }
    }

    private function getVersion()
    {
        if (get_option("rka_version")) {
            return get_option("rka_version");
        } else {
            return $this->setVersion();
        }
    }

    public function error_log($err): void
    {
        $filename = RAHKAR_ARUSH_PATH . "rka-log.txt";
        $error = vsprintf("[%s]: %s", [
            date("Y/m/d H:i:s"),
            $err
        ]);
        $log = fopen($filename, "w+");
        fwrite($log, $error);
        fclose($log);
    }
}